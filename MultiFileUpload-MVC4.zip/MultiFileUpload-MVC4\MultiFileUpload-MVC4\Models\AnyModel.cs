﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MultiFileUpload_MVC4.Models
{
    public class AnyModel
    {
        public int MyProperty { get; set; }

        public string FilesToBeUploaded { get; set; }
    }
}